#Building RESTful Web Services with PHP 7

Chapter 1, 4, 5, 9 do not have code files.